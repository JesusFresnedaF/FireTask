/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firetask;

/**
 *
 * @author jesus
 */
public class Temperature {

    private int temperaturas[][];
    private int width, height;
    private double percentageColdPoints, percentageSparks;

    public Temperature(int height, int width, double percentageColdPoint, double percentageSpark) {
        this.height = height;
        this.width = width;
        this.percentageColdPoints = percentageColdPoint;
        this.percentageSparks = percentageSpark;
        this.temperaturas = new int[height][width];
        initTemperaturas();
    }

    public Temperature(int height, int width) {
        this.height = height;
        this.width = width;
        System.out.println(this.height + " " + this.width);
        this.percentageColdPoints = 0.9;
        this.percentageSparks = 0.5;
        this.temperaturas = new int[height][width];
        initTemperaturas();
    }

    private void initTemperaturas() {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                temperaturas[i][j] = 0;

            }

        }
    }

    private void createSparks() {
        for (int j = 0; j < width; j++) {
            double probSpark = Math.random();
            if (probSpark <= percentageSparks) {
                temperaturas[height - 1][j] = 255;
            }

        }
    }

    private void creteColdPoints() {
        for (int j = 0; j < width; j++) {
            double probCold = Math.random();
            if (probCold <= percentageColdPoints) {
                temperaturas[height - 1][j] = 0;
            }

        }
    }

    private void calc() {
        //desde abajo hacia arriba
        for (int i = height - 2; i >= 0; i--) {
            //de izquierda a derecha
            temperaturas[i][0] = (int) ((temperaturas[i][0]*1.2D + temperaturas[i][1] * 1.2D + temperaturas[i + 1][0] * 0.7D + temperaturas[i + 1][2] * 0.7D) / 3.98569);
            temperaturas[i][width - 1] = (int) ((temperaturas[i][width - 1] * 1.2D + temperaturas[i][width - 2] * 1.2D + temperaturas[i + 1][width - 1] * 0.7D + temperaturas[i + 1][width - 2] * 0.7D) / 3.98569);
            for (int j = 1; j < width - 1; j++) {
                temperaturas[i][j] = (int) ((temperaturas[i][j]*1.5D + temperaturas[i][j + 1]*1.2D + temperaturas[i][j - 1]*1.2D  + temperaturas[i + 1][j - 1]*0.7D + temperaturas[i + 1][j]*0.7D + temperaturas[i + 1][j + 1]*0.7D) / 5.98569);
            }
        }
    }

    public void next() {
        creteColdPoints();
        createSparks();
        calc();
    }

    public int getTemp(int i, int j) {
        return temperaturas[i][j];
    }

}
