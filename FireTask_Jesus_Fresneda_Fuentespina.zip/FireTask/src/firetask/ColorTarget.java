/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firetask;

import java.awt.Color;

/**
 *
 * @author jesus
 */
public class ColorTarget {

    private int target;
    private Color color;

    public ColorTarget(int target, Color color) {
        this.target = target;
        this.color = color;
    }

    public int getTarget() {
        return target;
    }

    public void setTarget(int target) {
        this.target = target;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public int getRed() {
        return this.color.getRed();
    }

    public int getGreen() {
        return this.color.getGreen();
    }

    public int getBlue() {
        return this.color.getBlue();
    }

    public int getAlpha() {
        return this.color.getAlpha();
    }
    
    public boolean isMaxTarget(){
        return this.target == 255;
    }
    
    public boolean isMinTarget(){
        return this.target == 0;
    }

}
