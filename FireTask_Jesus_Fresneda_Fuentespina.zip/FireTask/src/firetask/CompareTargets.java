/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firetask;

import java.util.Comparator;

/**
 *
 * @author jesus
 */
public class CompareTargets implements Comparator<ColorTarget>{

    @Override
    public int compare(ColorTarget ct1, ColorTarget ct2) {
        if (ct1.getTarget() > ct2.getTarget()) {
            return 0;
        } else if (ct2.getTarget() > ct2.getTarget()) {
            return 1;
        } else {
            return -1;
        }
    }
}
