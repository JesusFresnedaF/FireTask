/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firetask;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author jesus
 */
public class Palette {

    private Color[] colorsPalette;
    private ArrayList<ColorTarget> colorsTarget;
    private static final int HEIGHT = 256;
    private static final int WIDTH = 4;

    public Palette() {
        this.colorsPalette = new Color[HEIGHT];
        this.colorsTarget = new ArrayList<>();
    }

    public void initColorTargets() {
        addColorTarget(0, 0, 0, 0, 0);//blanco
        addColorTarget(55, 0, 0, 0, 0);
        addColorTarget(60, 155, 0, 0, 0);
        addColorTarget(72, 200, 100, 0, 0);
        addColorTarget(112, 245, 150, 40, 80);
        addColorTarget(130, 255, 180, 50, 255);
        addColorTarget(255, 255, 255, 0, 255);

        calcIntervalColors();
    }

    public void addColorTarget(int target, int r, int g, int b, int a) {
        colorsPalette[target] = new Color(r, g, b, a);
        ColorTarget ct = new ColorTarget(target, colorsPalette[target]);
        this.colorsTarget.add(ct);
    }

    //calcular los colores según el target que introduce el usuario
    public void calcIntervalColors() {
        ordenarColorsTarget();
        for (int i = 1; i < colorsTarget.size(); i++) {
            ColorTarget filaInicio = colorsTarget.get(i - 1);
            ColorTarget filaFin = colorsTarget.get(i);
            calcInterval(filaInicio, filaFin);
        }
    }

    public void ordenarColorsTarget() {
        Collections.sort(colorsTarget, new CompareTargets());
    }

    public void calcInterval(ColorTarget filaInicio, ColorTarget filaFin) {
        int targetInicio = filaInicio.getTarget();
        int targetFin = filaFin.getTarget();
        for (int fila = targetInicio + 1; fila < targetFin; fila++) {
            int r = 0, g = 0, b = 0, a = 0;
            int incFilas = fila - targetInicio;
            int incTarget = targetFin - targetInicio;
            int incRed = filaFin.getRed() - filaInicio.getRed();
            int incGreen = filaFin.getGreen() - filaInicio.getGreen();
            int incBlue = filaFin.getBlue() - filaInicio.getBlue();
            int incAlpha = filaFin.getAlpha() - filaInicio.getAlpha();

            r = filaInicio.getRed() + (incFilas * incRed / incTarget);
            g = filaInicio.getGreen() + (incFilas * incGreen / incTarget);
            b = filaInicio.getBlue() + (incFilas * incBlue / incTarget);
            a = filaInicio.getAlpha() + (incFilas * incAlpha / incTarget);

            colorsPalette[fila] = new Color(r, g, b, a);
//            System.out.println(colorsPalette);
        }
    }

    public Color getColorI(int i) {
        return colorsPalette[i];
    }

}
