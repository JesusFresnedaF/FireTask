/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firetask;

import java.awt.Color;
import java.awt.image.BufferedImage;

/**
 *
 * @author jesus
 */
public class FireAnimation {

    private Temperature temperature;
    private Palette palette;
    BufferedImage img;
    private int height, width;

    public FireAnimation(int height, int width) {
        this.height = height;
        this.width = width;
        temperature = new Temperature(this.height, this.width);
        palette = new Palette();
    }
    
    //guardo el siguiente objeto color que calculo en la paleta según las temperaturas
    public Color next(int i, int j) {
        Color c = palette.getColorI(temperature.getTemp(i, j));
        return c;
    }
    
    //inicializo la paleta de colores
    public void initColorTargets(){
        this.palette.initColorTargets();
    }

    //creo la imagen del fuego según los colores obtenidos con las temperaturas
    public BufferedImage createFireImage() {
        img = new BufferedImage(this.width, this.height, BufferedImage.TYPE_INT_ARGB);
        for (int i = 0; i < this.height - 1; i++) {
            for (int j = 0; j < this.width; j++) {
                Color c = next(i, j);
                this.img.setRGB(j, i, c.getRGB());
            }

        }
        return img;
    }

    //calculo el siguiente frame de temperaturas
    public void nextTemp() {
        this.temperature.next();
    }

}
