/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firetask;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author jesus
 */
public class Viewer extends Canvas {

    FireAnimation fa;
    private int height;
    private int width;
    private BufferedImage img;
    private Image bgImage;
    private BufferStrategy bs;

    public Viewer(int height, int width, FireAnimation fa) {
        this.height = height;
        this.width = width;
        this.fa = fa;
        img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        setSize(width, height);
        loadBackground();
    }

    public void paintForeground() {
        if (this.bs == null) {
            this.createBufferStrategy(2);
            bs = this.getBufferStrategy();
        }

        Graphics g = bs.getDrawGraphics();
        fa.nextTemp();
        fa.initColorTargets();
        img = fa.createFireImage();
        g.drawImage(img, (int) (width/2.33), (int) (height/1.7), 220, 90, null);

        bs.show();
        g.dispose();
    }

    public void paintBackground() {
        if (this.bs == null) {
            this.createBufferStrategy(2);
            bs = this.getBufferStrategy();
        }

        Graphics g = bs.getDrawGraphics();
        g.drawImage(this.bgImage, 0, 0, this.getWidth(), this.getHeight(), null);
//        bs.show();
        g.dispose();
    }
    
    @Override
    public void show(){
        bs.show();
    }
    
    private void loadBackground() {
        try {
            this.bgImage = ImageIO.read(new File("bg.jpg"));

        } catch (IOException ex) {
            Logger.getLogger(Viewer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
