/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package firetask;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import static java.lang.Thread.sleep;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author jesus
 */
public class FireTask extends JFrame implements ComponentListener, ActionListener {

    FireAnimation fireAnimation;
    Viewer viewer;
    Color c;
    private JPanel panel;
    public static final int TEMP_HEIGHT = 95;
    public static final int TEMP_WIDTH = 220;
    private GridBagConstraints gbc;
    private JToggleButton tbPlay;

    public FireTask() {
        //configure the frame and panel
        configureFrame();
        addUIComponents();
        setVisible(true);
        //Bucle de fuego encendido
        pack();
    }

    private void configureFrame() {
        setSize(900, 900);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private void addUIComponents() {
        //inicializo el objeto gridbagconstraints
        gbc = new GridBagConstraints();
        //inicializo el panel y le añado el layout
        panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        //inicializo los botones, el viewer y añado el panel a la ventana
        initButtons();
        initClass();
        add(panel);
    }

    private void initClass() {
        //posición y tamaño del viewer en el gridbaglayout
        gbc.gridx = 4;
        gbc.gridy = 0;
        gbc.gridheight = 4;
        //inicializamos la animación, calculamos la primera matriz de temperaturas y añado targets a mano
        fireAnimation = new FireAnimation(TEMP_HEIGHT, TEMP_WIDTH);
        fireAnimation.nextTemp();
        //inicializo el viewer y lo añado al panel
        viewer = new Viewer((int) (500), (int) (550), fireAnimation);
        panel.add(viewer, gbc);
    }

    public void initButtons() {
        //añado un margen entre cada objeto del gridbaglayout
        gbc.insets = new Insets(10, 10, 10, 10);
        //creo los botones y les asigno un evento cuando lo pulsan
        //botón para pintar el fondo
        gbc.anchor = GridBagConstraints.WEST;
        gbc.gridx = 1;
        gbc.gridy = 0;

        //botón para iniciar la animación
        JButton btnFondo= new JButton("Mostrar Fondo");
        btnFondo.setPreferredSize(new Dimension(150, 40));
        btnFondo.addActionListener(this);
        panel.add(btnFondo, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;

        //botón para iniciar la animación
        tbPlay = new JToggleButton("Play/Stop");
        tbPlay.setPreferredSize(new Dimension(150, 40));
        tbPlay.addActionListener(this);
        panel.add(tbPlay, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        JButton btn1 = new JButton("Off");
        btn1.setPreferredSize(new Dimension(150, 40));
        btn1.addActionListener(this);
        panel.add(btn1, gbc);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String str = e.getActionCommand();
        switch (str) {
            case "Mostrar Fondo":
                this.viewer.paintBackground();
                this.viewer.show();
                break;
            case "Play/Stop":
                this.viewer.paintBackground();
                break;
            case "Off":
                this.viewer.paintBackground();
                this.tbPlay.setSelected(false);
                this.viewer.show();
                break;
            default:
                System.err.println("Acción NO tratada: " + e);
        }
    }

    //Pinto la animación del fuego
    public void paintAnimation() {
        while (true) {
            if (this.tbPlay.isSelected()) {
                this.viewer.paintBackground();
                this.viewer.paintForeground();
            }
            try {
                sleep(70);
            } catch (InterruptedException ex) {
                System.err.println(ex);
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        FireTask f = new FireTask();
        f.paintAnimation();
    }

    @Override
    public void componentResized(ComponentEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void componentMoved(ComponentEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void componentShown(ComponentEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void componentHidden(ComponentEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
